%projection_matrix
function key= Randomwalk_matrix(no_feature,step)

X=Randomwalk2(no_feature,step);
key=orth(X');
key=key/360;
%[q,r]=mgsog(projection_matrix');
%key=Q;
end