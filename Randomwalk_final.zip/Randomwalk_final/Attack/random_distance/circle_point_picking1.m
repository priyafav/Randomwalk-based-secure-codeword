%unit circle random points picking
function [xn,yn,dist,Angle]=circle_point_picking1(x,y)
 x0 = x+unifrnd(-1,1);
 x1 = y+unifrnd(-1,1); 
 if((x0-x)^2 + (x1-y)^2 >=1)
     x0 = x+unifrnd(-1,1);
     x1 = y+unifrnd(-1,1);
 end
 xn=x+(x0*x0 - x1*x1)/(x0*x0+x1*x1);
 yn=y+(2*x0*x1)/(x0*x0+x1*x1);
 %data=[xn,yn];
 dist=sqrt((xn-x)^2+(yn-y)^2);
  point_O=[x,y];
  point_P=[xn,yn];
[Angle,Radian]=getAngle(point_O,point_P);
end
