%projection_matrix
function [transformed_data] = Randomwalk_data(biometric_data,key)


transformed_data = biometric_data*key;

end