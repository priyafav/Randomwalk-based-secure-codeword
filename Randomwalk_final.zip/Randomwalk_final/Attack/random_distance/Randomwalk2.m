function projection_matrix=Randomwalk2(no_obj,step)
rng(1)
obj=(rand(no_obj,2));
data_matrix=[];
projection_matrix=[];
k=1;
for i=1:no_obj
 data=object_RW1([obj(i,1) obj(i,2)],step);
 data_matrix=[data_matrix,data];
 projection_matrix=[projection_matrix,data_matrix(:,4*k)];
 k=k+1;
end
 projection_matrix=projection_matrix(2:end,:);
end
 