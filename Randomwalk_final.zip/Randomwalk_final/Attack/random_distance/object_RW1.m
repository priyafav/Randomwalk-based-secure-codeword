%EACH OBJECT RANDOM WALK
function data=object_RW1(obj,step)
%step=100;
data=zeros(step,4);
%rng(1)
%data(1,1:2)=(2+rand(1,2));
data(1,1:2)=obj;
for j=2:step+1   
      [data(j,1),data(j,2),data(j,3),data(j,4)]=circle_point_picking1(data(j-1,1),data(j-1,2));           
 end
