function randomwalk_dist2=randomwalk_old1(no_obj,step)
rng(1)
obj=(rand(no_obj,2));
randomwalk_dist=[];
randomwalk_dist2=[];
direct=[[1,0];[1,1];[0,1];[-1,1];[-1,0];[-1,-1];[0,-1];[1,-1]];
for k=1:no_obj
   randomwalkd=[];
   ob1=obj(k,:);
   ob=ob1;
  
   %ob2=[];
 for i=1:step
   v=randi(8,1);
   dist=pdist2(ob1,ob1+direct(v,:)*0.5);
   randomwalkd=[randomwalkd,dist];
   ob1=ob1+direct(v,:)*0.5;
   %ob1
 end
 randomwalk_dist=[randomwalk_dist;randomwalkd];
end
randomwalk_dist2=randomwalk_dist';
end