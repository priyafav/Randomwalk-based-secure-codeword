clear all;
close all;
load('data\desr_2002_db1.mat');
load('data\temp_label.mat');
template_label=temp_label;
addpath('tool');
addpath_recurse('random_distance');
res_mat=[];
res_pso=[];
for i=1:5
 t=100*i+12;
d3=desr(:,1:t);
temp=d3;
x=d3;
hamming_imp_score=[];
hamming_gen_score=[];
hamming_dimension=t;
opts.dX=size(temp,2); %size of data
opts.model =Randomwalk_matrix(size(temp,2),hamming_dimension);
labels=ceil(0.1:0.125:9);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% sys_1 encrypt 

[transformed_data_sys1] = Randomwalk_data(temp,opts.model);
for i=1:72
    for j=1:72
       scores(i,j) = template_match1(transformed_data_sys1(i,:),transformed_data_sys1(j,:));
    end
end
k=1;
for i=1:length(labels)
   for j=1:length(labels) 
    if(labels(i)==labels(j))   
         hamming_gen_score =[hamming_gen_score,scores(i,j)];
    else
        hamming_imp_score =[hamming_imp_score,scores(i,j)];
    end
   
   end
end
hamming_gen_score = hamming_gen_score(find(hamming_gen_score~=1));
[EER_HASH_orig, mTSR, mFAR, mFRR, mGAR,threshold] =computeperformance1(hamming_gen_score, hamming_imp_score, 0.001); 
[FAR_orig,FRR_orig] = FARatThreshold(hamming_gen_score,hamming_imp_score,threshold);
 reconstruct_x=zeros(72,t);
%% reconstruct the first one sample
i=1;
disp(['reconstructing ',num2str(i)])
to_retrieve_hash=transformed_data_sys1((i-1)*8+1,:); % first of the template are used to reconstruct
%rng default % For reproducibility

f_fitness = @(x)fitness_randomwalk(x,to_retrieve_hash,opts); % fitness function
 f_constr = []; % constrain function
 
 approxmate_scores=[];
reconstruct_x(i,:) = reconstruct_plot(f_fitness,f_constr,opts);

% % a new sys, sys_2
opts.model =Randomwalk_matrix(size(temp,2),hamming_dimension);
[transformed_data_sys2] = Randomwalk_data(temp,opts.model);

[attacker_transformed_data] = Randomwalk_data(reconstruct_x(1,:),opts.model);
for i=1:72
  approxmate_scores(i) = template_match1(attacker_transformed_data,transformed_data_sys2(i,:));
end
[FAR_attack,FRR_attack] = FARatThreshold(hamming_gen_score,approxmate_scores,threshold);

disp(['Gen score mean: ',num2str(mean(hamming_gen_score))])
disp(['Score@ET: ',num2str(threshold)])
disp(['Mated-Imposter-score: ',num2str(approxmate_scores)])
disp(['FAR@ET: ',num2str(FAR_attack)])
res_mat=[res_mat;[EER_HASH_orig,FAR_orig,FRR_orig,FAR_attack,FRR_attack,threshold]];
res_pso=[res_pso;approxmate_scores];
end
