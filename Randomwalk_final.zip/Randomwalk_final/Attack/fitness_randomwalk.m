function [distance] = fitness_randomwalk(x, hashcode,opts)

[transformed_data] = Randomwalk_data(x,opts.model);

[distance] = 1 - template_match1(hashcode,transformed_data);
end