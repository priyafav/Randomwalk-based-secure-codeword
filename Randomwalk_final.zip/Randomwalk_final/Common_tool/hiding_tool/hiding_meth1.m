Image= magic(512);
X=Randomwalk2(120,100);
%load('randomwalkdistance_new.mat');
r=100;
s=120;
rng(4);%%%%
row=randi([1 r],1);
col=randi([1 s],1);

if(row<(size(Image,1)-r) && col<(size(Image,1)-s))
    matrix1=Image(row:row+r-1,col:col+s-1);
    m=matrix1;
elseif(col<(size(Image,1)-s))
    matrix1=Image(row:size(Image,1),col:col+s-1);
    matrix2=Image(1:r-size(matrix1,1),col:col+s-1);
    m=[matrix1,matrix2];
elseif(row<(size(Image,1)-r))
    matrix1=Image(row:row+s-1,col:size(Image,2));
    matrix2=Image(row:row+r-1,1:s-size(matrix1,2));
    m=[matrix1,matrix2];
else
    matrix1=Image(row:size(Image,1),size(Image,2));
    matrix2=Image(1:r-size(matrix1,1),1:s-size(matrix1,2));
    m=[matrix1,matrix2];
end 

altered_matrix=[];
for i=1:r
    for j=1:s
        altered_matrix(i,j)=X(i,j)*double(m(i,j));
    end
end    
original_matrix=[];
for i=1:r
    for j=1:s
        original_matrix(i,j)=altered_matrix(i,j)/double(m(i,j));
    end
end         
    