X=Randomwalk2(120,100);
r = randperm(120);
seq=r;
s=100;
a_mat=[];
for i=1:r
   for j=1:s
    a_mat(i,j)=X(i,r(j));
   end
   r = circshift(r,3);
end 
