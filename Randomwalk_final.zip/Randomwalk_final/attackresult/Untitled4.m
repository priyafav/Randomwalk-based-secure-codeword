x1 = 0.01:0.01:1;
 y1 = [sin(pi*x1) zeros(1,20)];
 x2 = x1+0.2;
 y2 = [zeros(1,20) sin(pi*x1)];
 y_d = [y2(y2<y1) y1(y1<y2)]; 
 area_int  = trapz(y_d)
 %plots in case you want to visualize
 plot(y1)
 hold on
 plot(y2)
 plot(y_d,'k-o')