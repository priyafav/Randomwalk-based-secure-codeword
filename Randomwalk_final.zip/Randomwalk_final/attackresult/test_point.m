function [val,yval]=test_point(mu1,var1,mu2,var2)
yfun = @(mu,var, x)(2*pi*(var))^(-0.5)* exp(-((x-mu).^2)/(2*(var)));
val = fzero(@(x) yfun(mu1, var1, x) - yfun(mu2, var2, x), mean([mu1,mu2]));
yval = yfun(mu1, var1, val);
end