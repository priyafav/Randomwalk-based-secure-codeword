%
[g_score1,seq]=genuinue1();
%[imp_score1,seq1]=pseudo_imposter();
load('res_psofvc2002db1biohashing.mat');
imp_score1=res_pso(5,:)';
[imp_score2,seq2]=imposter1();
%range1=0.01:.001651:1;
range1=0:0.01:1;
g_score1_hist = histc(g_score1,range1);
imp_score1_hist = histc(imp_score1,range1);
imp_score2_hist=histc(imp_score2,range1);
g_score1_pdf = g_score1_hist;
imp_score1_pdf = imp_score1_hist;
imp_score2_pdf = imp_score2_hist;
%%%%%%%%%%%%%AREA%%%%%%%%%%
y1=imp_score1_hist;
y2=imp_score2_hist;
 y_d = (y2(y2<y1)); 
 y_d1= (y1(y1<y2));
 area_int=trapz(y_d);
 area_int1=trapz(y_d1);
%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1),%plot(range1,g_score1_pdf, 'MarkerFaceColor','g');
plot(range1,g_score1_pdf,'-r','LineWidth',2,...
'MarkerEdgeColor','k',...
'MarkerFaceColor','g',...
'MarkerSize',3)
hold on;
plot(range1,imp_score1_pdf,'-k','LineWidth',2,...
'MarkerEdgeColor','k',...
'MarkerFaceColor','r',...
'MarkerSize',3)
xlabel('Match Score');
ylabel('Frequency');

hold on;
plot(range1,imp_score2_pdf,'-g','LineWidth',2,...
'MarkerEdgeColor','k',...
'MarkerFaceColor','r',...
'MarkerSize',3)

xlabel('Match Score');
ylabel('Frequency');
mu1=mean(g_score1);
var1=var(g_score1);
mu2=mean(imp_score1);
var2=var(imp_score1);
[val,yval]=test_point(mu1,var1,mu2,var2);
[ d,oa ] = bivariate_overlap_integral(mu1,var1,mu2,var2);
title('Simility-attack Analysis');
legend1 = sprintf('Genuine(mean = %.01f)', mean(g_score1));
legend2 = sprintf('Mated-imposter(mean = %.3f)', mean(imp_score1));
legend3 = sprintf('Imposter(mean = %.3f)', mean(imp_score2));
legend({legend1, legend2,legend3},'Orientation','horizontal','Location','best');
hold off