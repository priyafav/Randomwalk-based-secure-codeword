function [impo1]=brute_force()
temp=load('highresolutionnon_matrix.mat');
r1=min(min(temp.Non_matrix));
r2=max(max(temp.Non_matrix));
key1=temp.Non_matrix;
impo1=[];
sequence=[];
for i = 1:100
    similiraty=[];
    template1=key1(i,:);
    for j=1:1000
     %rng(j)
     template2=r1+ (r2-(r1)).*rand(1000,1);
     C2=template_match(template1,template2);
     similiraty=[similiraty,C2];
    end
     impo1 = [impo1; max(similiraty)];
 end
end