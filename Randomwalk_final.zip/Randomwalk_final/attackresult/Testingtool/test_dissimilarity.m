load('desrnon_matrix_2002_db1.mat');
dt=[Non_matrix];
for i=1:8
    for j=9:72
     dist(i,j)=512-sum(dt(i,1:512)==dt(j,1:512));
    end
end

% for i=9:18
%     for j=19:72
%      dist(i,j)=sum(cd3(i,:)==cd3(j,:));
%     end
% end

ds=dist(find(dist~=0));
histfit(ds); hold on
xlabel('Hamming distance(inter-class)');
ylabel('Frequency');
title('Dissimilarity analysis');
% [f,xi] = ksdensity(ds);
% hold on
% plot(xi,f)
% hist(dist,452);
% yourChargeArray=dist;
% histogram(yourChargeArray); % Display histogram
% countOfCharges = sum(yourChargeArray(:) ~= 0)
% totalCharges = sum(yourChargeArray(:))
% averageChargeValue = mean(yourChargeArray(:));
% maxChargeValue = max(yourChargeArray(:));