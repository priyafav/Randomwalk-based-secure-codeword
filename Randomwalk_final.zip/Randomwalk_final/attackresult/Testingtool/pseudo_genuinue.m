%Pseudo-genuniue scores:
function [gen,sequence]=pseudo_genuinue()
temp=load('highresolutionnon_matrix.mat');
key=temp.Non_matrix;
temp1=load('highresolutionnon_matrixold.mat');
key1=temp1.Non_matrix;
gen=[];
sequence=[];
 for i = 1:100
    combination = nchoosek(1:5, 2);    
     for j = 1:length(combination)
        file1 = combination(j,:);
        sequence=[sequence;[(i-1)*5+file1(1) ,(i-1)*5+file1(2)]];
        template1=key((i-1)*5+file1(1),:);
      
        template2=key1((i-1)*5+file1(2),:);
       
        C2=template_match(template1,template2);
        similiraty=C2;
        gen = [gen; similiraty];
     end
 end
end