function randomwalk_dist1=randomwalk_old(no_obj,step)
rng(1)
obj=(rand(no_obj,2));
randomwalk_dist=[];
randomwalk_dist1=[];
direct=[[1,0];[1,1];[0,1];[-1,1];[-1,0];[-1,-1];[0,-1];[1,-1]];
for k=1:no_obj
   randomwalkd=[]; 
   ob1=obj(k,:);
   ob=ob1;
   %ob2=[];
   
 for i=1:step
   v=randi(8,1);
   dist=pdist2(ob1,ob+direct(v,:)*1);
  % dist
   randomwalkd=[randomwalkd,dist];
   ob=ob+direct(v,:)*1;
   %ob
 end
 randomwalk_dist=[randomwalk_dist;randomwalkd];
end
randomwalk_dist1=randomwalk_dist';
end