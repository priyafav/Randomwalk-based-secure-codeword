function [impo1]=brute_force1()
r1=-2.3;
r2=2.4;
temp=load('feature_vector_randomwalk3.mat');
X=randomwalk_old1(120,100);%randomwalk matrix
[Q] = orth(X');%orthogonalised matrix
key1=temp.d3*(Q);
impo1=[];
sequence=[];
for i = 1:72
    similiraty=[];
    template1=key1(i,:);
    for j=1:1000
     rng(j)
     template2=r1+ (r2-(r1)).*rand(100,1);
     C2=template_match(template1,template2);
     similiraty=[similiraty,C2];
    end
     impo1 = [impo1; max(similiraty)];
 end
end