%Pseudo-genuniue scores:
function [gen,sequence]=pseudo_genuinue1()
temp=load('feature_vector_randomwalk3.mat');
X=randomwalk_old(120,100);%randomwalk matrix
[Q1.Q] = orth(X');%orthogonalised matrix
X1=Randomwalk2(120,100);%randomwalk matrix
[Q2.Q] = orth(X1');%orthogonalised matrix
key=temp.d3*Q1.Q;
key1=temp.d3*Q2.Q;
gen=[];
sequence=[];
 for i = 1:9
    combination = nchoosek(1:8, 2);    
     for j = 1:length(combination)
        file1 = combination(j,:);
        sequence=[sequence;[(i-1)*8+file1(1) ,(i-1)*8+file1(2)]];
        template1=key((i-1)*8+file1(1),:);
      
        template2=key1((i-1)*8+file1(2),:);
       
        C2=template_match(template1,template2);
        similiraty=C2;
        gen = [gen; similiraty];
     end
 end
end