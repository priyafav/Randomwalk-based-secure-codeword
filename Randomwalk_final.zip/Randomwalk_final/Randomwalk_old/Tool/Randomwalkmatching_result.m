X=randomwalk_old1(512,512);%randomwalk matrix
[Q] = orth(X');%orthogonalised matrix
temp=load('highresolution.mat');
Non_matrix=temp.d4*Q;
result=[];
Matched_FigerPrints=[];
for i=1:72
    for j=1:72
        result(i,j)=template_match1(Non_matrix(i,:),Non_matrix(j,:));
    end
    Matched_FigerPrints{i}=find(result(i,:)>0.60);
end
