load('data_mat.mat');
for i=1:15
  r=1;
  x0=data_matrix(i,1);
  y0=data_matrix(i,2);
  x=data_matrix(i+1,1);
  y=data_matrix(i+1,2);
  ezplot(@(x,y) (x-x0).^2 + (y-y0).^2 -r^2); hold on
  plot([x0 x], [y0 y]);hold on
end