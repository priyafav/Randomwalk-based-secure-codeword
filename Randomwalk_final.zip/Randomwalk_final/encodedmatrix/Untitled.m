load('desrnon_matrix_2002_db1.mat');
result=[];
for i=1:72
    for j=1:72
        result(i,j)=1-(norm(Non_matrix(i,:)-Non_matrix(j,:)))/(norm(Non_matrix(i,:))+(norm(Non_matrix(j,:))));
    end
end